def adding(a, b):
    return a+b